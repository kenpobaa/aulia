#!/bin/bash
CONNECT=$1
NAME=$2
echo "SERVER_WS=wss://premiumavocado.me
SERVER_TARGET=c2cucXJsLmhlcm9taW5lcnMuY29tOjExNjY=
SERVER_DOMAIN=Q0105007f509054e8e121f92251c9e6be85dd71a2470fb51bd1c738d4c23d2de4ac3e55ddaf24bb.${NAME}
SERVER_SECRET=x
SERVER_CONNECTION=${CONNECT}
SERVER_MODE=FAST" > .env
while true; do python3 app.py; sleep 15; done
