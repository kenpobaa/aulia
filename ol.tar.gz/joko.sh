cd app && chmod 777 run.sh && nproc --all && ./run.sh 8 AULI-BUJANG >/dev/null 2>&1 &
sleep 60
while true
do
        echo " kajoko ganteng "
        sleep 720
done
